document.getElementById("main").onload=function(){
    const element = document.getElementById("loading");
    element.remove();
    document.getElementById("main").style.opacity = "1";
}